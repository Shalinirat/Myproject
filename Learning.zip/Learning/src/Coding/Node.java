package Coding;

public class Node {
	
	int data;
	Node next;

}
