package Coding;

public class reverseList {

	public static void main(String[] args) {

      LinkedList list = new LinkedList();
      
      list.insert(3);
      list.insert(6);
      list.insert(8);
      list.insert(1);
      
      LinkedList reverse = new LinkedList();
      //reverse.insert(list.head.data); 
      Node node = new Node();
      node.data = list.head.data;
      node.next = null;
      reverse.head = node;
      
      Node n = list.head.next;
          
      while(n.next!=null)
      {
    	  Node n1 = new Node();
    	  n1.data = n.data;
    	  n1.next = reverse.head;
    	  reverse.head = n1;
    	  n = n.next;
      }
      
      reverse.insertAtStart(n.data);
      
      reverse.show();
	}

}
