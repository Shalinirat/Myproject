package Coding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Leetcode2 {

	public static void main(String[] args) {
		
		//remove element from array
		int[] arr = {3,2,2,3};
		int val = 3;
		
//		int i = 0;
//		int j = arr.length-1;
//		
//		for(int k=0;k<arr.length;k++)
//		{
//			if(arr[i]==val) {
//				arr[i]=arr[j];
//				arr[j]=0;
//				j--;
//			}
//			else
//				i++;
//		}
//		
//		System.out.println(Arrays.toString(arr));
//		System.out.println(i);
		
		List<Integer> l = new ArrayList<>();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]!=val) 
				l.add(arr[i]);	
		}
		
		System.out.println(l);
	}

}
