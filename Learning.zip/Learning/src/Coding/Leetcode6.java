package Coding;

import java.util.Arrays;

public class Leetcode6 {

	public static void main(String[] args) {

      //rotate array to the right by k time
		int[] arr = {4,7,1,9,-1,0,8,1,-4,10,3};
		int k = 13;
		int n = arr.length;
		k = k%n;
		rotate(arr,0,n-1);
		rotate(arr,0,k-1);
		rotate(arr,k,n-1);
		
		System.out.println(Arrays.toString(arr));
	}
	
	public static void rotate(int[] arr, int start, int end)
	{
		while(start<end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
	}
}

