package test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Day2 {
	
	@Test
	public void test()
	{
		System.out.println("testing");
	}
	

	@AfterTest
	public void executeEnd()
	{
		System.out.println("I will execute end of all methods");
	}

}
