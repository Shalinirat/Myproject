package test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day3 {
	
	@BeforeClass
	public void beforallmethod()
	{
		System.out.println("beforallmethod");
	}
	
	@AfterClass
	public void afterallmethod()
	{
		System.out.println("afterallmethod");
	}
	
	@Parameters({"URL"})
	@Test
	public void webLoginCar(String url)
	{
		System.out.println("webLoginCar");
		System.out.println(url);
	}
	
	@Test(groups= {"Smoke"})
	public void mobileLoginCar()
	{
		System.out.println("mobileLoginCar");
	}
	
	@Test(enabled=false)
	public void mobileSigninCar()
	{
		System.out.println("mobileSigninCar");
	}
	
	@Test(dataProvider= "getData")
	public void mobileSignoutCar(String username, String password)
	{
		System.out.println("mobileSignoutCar");
		System.out.println(username);
		System.out.println(password);
	}
	
	@Test(dependsOnMethods= {"webLoginCar"})
	public void apiLoginCar()
	{
		System.out.println("apiLoginCar");
	}
	
	@BeforeTest
	public void executeFirst()
	{
		System.out.println("I will execute before all method");
	}
	
	@DataProvider
	public Object[][] getData()
	{
		//1st username, password - good credit hit
		//2nd username, passowrd - no credit hit
		//3rd flaudelent credit history
		
		Object[][] data = new Object[3][2];
		
		data[0][0]="firstUsername";
		data[0][1]="firstPassword";
		
		data[1][0]="secondUsername";
		data[1][1]="secondPassword";
		
		data[2][0]="thirdUsername";
		data[2][1]="thirdPassword";
		
		return data;
	}

}
