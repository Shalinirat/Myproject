package Coding;

public class LinkedListMedian {

	public static void main(String[] args) {

        LinkedList list = new LinkedList();
        
        list.insert(5);
        list.insert(4);
        list.insert(8);
        list.insert(12);
        list.insert(10);
        list.insertAtStart(9);       
        list.insertAt(3, 16);
        list.insert(2);
        
        list.show();
	
		Node slow = list.head;
		Node fast = list.head;
		
		int median = 0;
		
		while(slow.next!=null)
		{		
			if(fast.next==null) {
				median = slow.data;
				break;
			}
			
			else if(fast.next.next==null) {
				median = (slow.data + slow.next.data)/2;
				break;
			}
				
			slow = slow.next;
			fast = fast.next.next;
		}
		
		System.out.println(median);
		
	}

}
