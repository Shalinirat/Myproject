package test;

import org.testng.ITestListener;

public class Listeners implements ITestListener {

}
