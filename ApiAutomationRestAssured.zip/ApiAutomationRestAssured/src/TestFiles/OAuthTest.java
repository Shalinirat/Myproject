package TestFiles;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;

import PojoClassses.Api;
import PojoClassses.GetCourses;
import PojoClassses.WebAutomation;

public class OAuthTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] courses = {"Selenium Webdriver Java", "Cypress", "Protractor"};
		
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		String response = given().formParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
		.formParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W")
		.formParam("grant_type", "client_credentials")
		.formParam("scope", "trust")
		.log().all().when().post("oauthapi/oauth2/resourceOwner/token")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath js = new JsonPath(response);
		String authToken = js.getString("access_token");
		
		GetCourses gcResponse = given().queryParam("access_token", authToken)
		.log().all().when().get("oauthapi/getCourseDetails")
		.then().log().all().extract().response().as(GetCourses.class);
		
		System.out.println(gcResponse.getLinkedIn());
		
		List<Api> api = gcResponse.getCourses().getApi();
		for(int i=0;i<api.size();i++)
		{
			if(api.get(i).getCourseTitle().equalsIgnoreCase("Rest Assured Automation using Java"))
				System.out.println(api.get(i).getPrice());
		}
		
		ArrayList<String> actualCourses = new ArrayList<String>();
		
		List<WebAutomation> wa = gcResponse.getCourses().getWebAutomation();
		for(int i=0;i<wa.size();i++)
		{
			actualCourses.add(wa.get(i).getCourseTitle());
		}
		
		List<String> expectedCourses = Arrays.asList(courses);
		
		Assert.assertTrue(actualCourses.equals(expectedCourses));

	}

}
