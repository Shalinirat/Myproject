package Coding;

public class Leetcode7and8 {

	public static void main(String[] args) {
		
		//best time to buy and sell I and II
		//I
		int[] arr = {7,1,5,3,6,4};
		int buy = arr[0];
		int profit = 0;
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]<buy)
				buy=arr[i];
			else
				profit = Math.max(profit, arr[i]-buy);
		}		
		System.out.println(profit);
		
		//II
        int buyNew = arr[0];
        int maxProfit = 0;       
        for(int i=1;i<arr.length;i++)
        {
        	if(arr[i]>buyNew)
        		maxProfit = maxProfit+(arr[i]-buyNew);
        	
        	buyNew = arr[i];
        }       
        System.out.println(maxProfit);
	}

}
