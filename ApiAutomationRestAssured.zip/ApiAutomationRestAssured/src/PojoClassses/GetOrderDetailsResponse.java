package PojoClassses;

public class GetOrderDetailsResponse {
	
	private OrderDetails data;
	private String message;
	
	public OrderDetails getData() {
		return data;
	}
	public void setData(OrderDetails data) {
		this.data = data;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
