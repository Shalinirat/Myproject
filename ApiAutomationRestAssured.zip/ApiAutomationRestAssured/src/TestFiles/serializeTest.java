package TestFiles;

import org.testng.annotations.Test;

import PojoClassses.AddPlaceRequest;
import PojoClassses.AddPlaceResponse;
import PojoClassses.Location;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.List;

public class serializeTest {
	
	@Test
	public void addPlace() {
		
	AddPlaceRequest p = new AddPlaceRequest();
	Location l = new Location();
	l.setLat(-38.383494);
	l.setLng(33.427362);
	
	p.setLocation(l);
	p.setAccuracy(50);
	p.setName("Frontline house");
	p.setPhone_number("(+91) 983 893 3937");
	p.setAddress("29, side layout, cohen 09");
	
	List<String> type = new ArrayList<>();
	type.add("shoe park");
	type.add("shop");
	p.setTypes(type);
	
	p.setWebsite("http://netflix.com");
	p.setLanguage("English");
		
	RestAssured.baseURI ="https://rahulshettyacademy.com";
	AddPlaceResponse response =  given().log().all().queryParam("key", "qaclick123")
	.header("Content-Type","application/json")
	.body(p)
	.when().post("maps/api/place/add/json")
	.then().log().all().assertThat().statusCode(200).extract().response().as(AddPlaceResponse.class);
	
	System.out.println(response.getPlace_id());
	
	}

}
