import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scope {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://qaclickacademy.com/practice.php");
		driver.manage().window().maximize();
		
		// 1. find links count on the page
		System.out.println(driver.findElements(By.tagName("a")).size());
		
		//2. find links count on the footer area of page	
		  //limit the driver
		WebElement footerDriver = driver.findElement(By.id("gf-BIG"));	
		System.out.println(footerDriver.findElements(By.tagName("a")).size());
		
		//3. find links count in first column of footer
		
		WebElement columnDriver = footerDriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		System.out.println(columnDriver.findElements(By.tagName("a")).size());
		
		//4. Click on each link in the column and open in new tab and print title name
		
		int linkCount = columnDriver.findElements(By.tagName("a")).size();
		for(int i=1;i<linkCount;i++)
		{
			//to store a string which store ctrl+click(to open link in new tab)
			String clickonlink = Keys.chord(Keys.CONTROL,Keys.ENTER);			
			columnDriver.findElements(By.tagName("a")).get(i).sendKeys(clickonlink);
		}
		
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		
		while(it.hasNext())
		{
		
			driver.switchTo().window(it.next());			
			System.out.println(driver.getTitle());
		}

	}

}
