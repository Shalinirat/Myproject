package test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day1 {
	
	@Test(groups= {"Smoke"})
	public void demo()
	{
		System.out.println("hello");
	}
	
	@Parameters({"URL"})
	@Test
	public void demo2(String url)
	{
		System.out.println("Hiii");
		System.out.println(url);
	}

	@AfterSuite
	public void executeLatnumber()
	{
		System.out.println("I will execute at the last");
	}

}
