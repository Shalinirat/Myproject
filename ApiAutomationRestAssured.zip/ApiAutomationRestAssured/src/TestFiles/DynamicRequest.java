package TestFiles;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadFiles.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class DynamicRequest {
	
	
	@Test(dataProvider="bookData")
	public void addBook(String isbn, String aisle)
	{
		
		RestAssured.baseURI = "http://216.10.245.166";
		//add book
		String response = given().log().all().header("Content-Type","application/json").body(Payload.addBookPayload(isbn,aisle))
				          .when().post("Library/Addbook.php")
				          .then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath js = new JsonPath(response);
		String id = js.getString("ID");
		System.out.println(id);
		
		//delete book
		given().log().all().header("Content-Type","application/json")
		.body("{\r\n"
				+ "\"ID\": \""+id+"\"\r\n"
				+ "}").when().delete("/Library/DeleteBook.php")
		.then().log().all().assertThat().statusCode(200).body("msg", equalTo("book is successfully deleted"));
	}
	
	@DataProvider(name="bookData")
	public Object[][] getData()
	{
		//array=collection of elements
		//multidimensional array= collection of arrays
		return new Object[][] {{"iuyu","234"},{"lkjp","765"},{"mnbw","879"}};
	}

}
