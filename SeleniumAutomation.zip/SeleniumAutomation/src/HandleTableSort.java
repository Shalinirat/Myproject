import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class HandleTableSort {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		driver.manage().window().maximize();
		
		//find the vaggies name from table and check if it's sortedor not
		
		//click on table to sort
		driver.findElement(By.cssSelector(".sort-icon.sort-descending")).click();
		
		//store webelement present in table in list
		List<WebElement> elementList = driver.findElements(By.xpath("//tr/td[1]"));
		
		// store name of all webelements in other list - original list
		List<String> originalList = elementList.stream().map(s->s.getText()).collect(Collectors.toList());
		
		// sort the original list - sorted list
		List<String> sortedList = originalList.stream().sorted().collect(Collectors.toList());
		
		// compare original lit to sorted list
		Assert.assertTrue(originalList.equals(sortedList));
		
		//Scan the name cloums with getText() and print the price of Strawberry(as Strawberry is not on same page)
		//pagination
		List<String> price;
		
		do {
				
	    List<WebElement> rows = driver.findElements(By.xpath("//tr/td[1]"));
	    
		price = rows.stream().filter(s->s.getText().contains("Strawberry")).map(s->getVeggiePrice(s)).collect(Collectors.toList());
        price.forEach(s->System.out.println(s));
        
        if(price.size()<1)
        	driver.findElement(By.cssSelector("[aria-label='Next']")).click();
		
		}while(price.size()<1);
		
		
		
		//Filter vaggeis name with a keyword and check weather filtered vaggies having that keywords
		
		driver.findElement(By.id("search-field")).sendKeys("Rice");
		//get list of elements after search
		List<WebElement> Vaggies = driver.findElements(By.xpath("//tr/td[1]"));
		// get list of filter elements
		List<WebElement> filterVaggies = Vaggies.stream().filter(s->s.getText().contains("Rice")).collect(Collectors.toList());
		
		Assert.assertEquals(Vaggies, filterVaggies);
		
	}
	
	public static String getVeggiePrice(WebElement s)
	{
		String price = s.findElement(By.xpath("following-sibling::td[1]")).getText();
		return price;
	}

}
