package TestFiles;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;

import PayloadFiles.Payload;
import PojoClassses.AddPlaceRequest;
import PojoClassses.Location;

public class SpecBuilder {

	public static void main(String[] args) {
     //given - all input details - headers, query param, body
     //when - submit the API - resourse, http method
     //then		
	
	 RequestSpecification req = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addQueryParam("key", "qaclick123")
	 .setContentType(ContentType.JSON).build();
	 
	 ResponseSpecification res = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
	 
	 AddPlaceRequest p = new AddPlaceRequest();
	 Location l = new Location();
    	l.setLat(-38.383494);
		l.setLng(33.427362);
		
		p.setLocation(l);
		p.setAccuracy(50);
		p.setName("Frontline house");
		p.setPhone_number("(+91) 983 893 3937");
		p.setAddress("29, side layout, cohen 09");
		
		List<String> type = new ArrayList<>();
		type.add("shoe park");
		type.add("shop");
		p.setTypes(type);
		
		p.setWebsite("http://netflix.com");
		p.setLanguage("English");
	 	
     //Add place - update place address and get result if address is updated ot not
	 RequestSpecification request = given().log().all().spec(req)
	 .body(p);
	 
	 String response = request.when().post("/maps/api/place/add/json").then().log().all().spec(res)
	 .body("scope", equalTo("APP")).header("Server", "Apache/2.4.52 (Ubuntu)").extract().response().asString();
	 
	 System.out.println(response);
	 JsonPath js = new JsonPath(response);
	 String placeId = js.getString("place_id");
	 
	 System.out.println(placeId);

	 String newAddress = "791 Summers walk, Africa";
	 //update address
	 given().log().all().spec(req).queryParam("place_id", placeId)
	 .body("{\r\n"
	 		+ "\"place_id\":\""+placeId+"\",\r\n"
	 		+ "\"address\":\""+newAddress+"\",\r\n"
	 		+ "\"key\":\"qaclick123\"\r\n"
	 		+ "}").when().put("/maps/api/place/update/json").then().log().all().spec(res)
	        .body("msg", equalTo("Address successfully updated"));
	 
	 //get updated place
	 String getResponse = given().log().all().spec(req).queryParam("place_id", placeId).when().get("/maps/api/place/get/json")
	 .then().log().all().spec(res).extract().response().asString();
	 
	 JsonPath js1 = new JsonPath(getResponse);
	 String updatedAddress = js1.getString("address");
	 
	 
	 Assert.assertTrue(newAddress.equalsIgnoreCase(updatedAddress));
	 
	}

}
