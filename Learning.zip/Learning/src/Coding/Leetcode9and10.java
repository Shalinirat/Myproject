package Coding;

public class Leetcode9and10 {
	
	public static void main(String[] args)
	{
		//jump I
		int[] arr1 = {3,2,1,0,4};
		int last = arr1.length-1;
		
		for(int i=arr1.length-2;i>=0;i--)
		{
			if(arr1[i]>=last-i)
				last = i;
		}
		
		if(last==0)
			System.out.println("true");
		else
			System.out.println("false");
		
		//jump II
		int[] arr2 = {2,3,1,1,4};
		int destination = arr2.length-1;
		int coverage = 0;
		int lastIdx = 0;
		int jumpCount = 0;
		
		for(int i=0;i<arr2.length;i++)
		{
		   coverage = Math.max(coverage, i+arr2[i]);
		   

		   if(lastIdx==i)
		   {
			  lastIdx = coverage;
			  jumpCount++;
			  
			  if(lastIdx>=destination)
				  break;
		   }
		}
		
		System.out.println(jumpCount);
		
	}

}
