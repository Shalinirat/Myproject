import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment6 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://qaclickacademy.com/practice.php");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("checkBoxOption3")).click();
		
		String option = driver.findElement(By.cssSelector("[for='honda']")).getText();
		System.out.println(option);
		
		WebElement selectdropdown = driver.findElement(By.id("dropdown-class-example"));
		Select dropdown = new Select(selectdropdown);
		dropdown.selectByVisibleText(option);
		
		driver.findElement(By.id("name")).sendKeys(option);
		
		driver.findElement(By.cssSelector("#alertbtn")).click();
		
		String alertText = driver.switchTo().alert().getText();
		
		if(alertText.contains(option))
			System.out.println("Text is present");
		
		else
			System.out.println("Text is not present");

	}

}
