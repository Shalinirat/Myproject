import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class SpicejetE2E {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[text()='one way']")).click();
		driver.findElement(By.xpath("//div[text()='From']")).click();
		driver.findElement(By.xpath("//div[text()='India']")).click();
		driver.findElement(By.xpath("//div[text()='BLR']")).click();
		driver.findElement(By.xpath("//div[text()='International']")).click();
		driver.findElement(By.xpath("//div[text()='BKK']")).click();
		driver.findElement(By.xpath("//div[@data-testid='undefined-month-May-2024'] //div[text()='18']")).click();

		if (driver.findElement(By.cssSelector(".css-76zvg2.css-bfa6kz.r-homxoj.r-ubezar.r-icoktb"))
				.getAttribute("style").contains("opacity: 1")) {
			System.out.println("It's Enable");
			Assert.assertTrue(false);
		} else {
			System.out.println("It's Disable");
			Assert.assertTrue(true);
		}

		driver.findElement(By.xpath("//div[text()='1 Adult']")).click();
		Thread.sleep(2000);
		for (int i = 1; i < 5; i++) {
			driver.findElement(By.xpath("//div[@data-testid='Adult-testID-plus-one-cta']")).click();
		}

		driver.findElement(By.xpath("//div[@data-testid='home-page-travellers-done-cta']")).click();

		driver.findElement(By.xpath("//div[text()='INR']")).click();
		driver.findElement(By.xpath("//div[text()='USD']")).click();
		driver.findElement(By.xpath("//div[text()='Family & Friends']")).click();
		driver.findElement(By.xpath("//div[@data-testid='home-page-flight-cta']")).click();

		driver.findElement(By.cssSelector("rect[width='100%']")).click();
		driver.findElement(By.cssSelector(
				".css-1dbjc4n.r-1awozwy.r-z2wwpe.r-1loqt21.r-18u37iz.r-1777fci.r-d9fdf6.r-1w50u8q.r-ah5dr5.r-1otgn73"))
				.click();

	}

}
