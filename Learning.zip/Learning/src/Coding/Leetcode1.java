package Coding;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Leetcode1 {
	
	public static void main(String args[])
	{		
		//Merge 2 array and sort using java 8
		int[] a1 = {3,5,1,8,0};
		int[] a2 = {6,4,7,9,2};
		int[] a3 = IntStream.concat(Arrays.stream(a1), Arrays.stream(a2)).sorted().toArray();
		System.out.println(Arrays.toString(a3));
		
		
		//merge 2 sorted array
		int[] arr1 = new int[10];
		int[] arr2 = new int[5];
		
		for(int i=0;i<arr2.length;i++)
		{
			arr1[i]=i+1;
			arr2[i]=i+10;
		}
		
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
		
		int k = 0;
		for(int j=arr2.length;j<arr1.length;j++)
		{
			arr1[j]=arr2[k];
			k++;
		}
		
		Arrays.sort(arr1);
		System.out.println(Arrays.toString(arr1));
	}
}
