package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Day4 {
	
	@BeforeMethod
	public void beforeeachmethod()
	{
		System.out.println("beforeeachmethod");
	}
	
	@AfterMethod
	public void aftereachmethod()
	{
		System.out.println("aftereachmethod");
	}
	
	@Parameters({"URL","APIKey"})
	@Test
	public void webLoginHome(String url, String key)
	{
		System.out.println("webLoginHome");
		System.out.println(url);
		System.out.println(key);
	}
	
	@Test
	public void mobileLoginHome()
	{
		System.out.println("mobileLoginHome");
	}
	
	@Test(groups= {"Smoke"})
	public void apiLoginHome()
	{
		System.out.println("apiLoginHome");
	}
	
	@Test
	public void apiLogoutHome()
	{
		System.out.println("apiLogoutHome");
	}
	
	@BeforeSuite
	public void executefirstnumber()
	{
		System.out.println("I will execute no 1");
	}

}
