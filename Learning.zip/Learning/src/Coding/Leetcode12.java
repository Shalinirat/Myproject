package Coding;

import java.util.HashMap;
import java.util.Map;

public class Leetcode12 {

	public static void main(String[] args) {


		//roman to integer
		String roman = "MCMXCIV";
		Map<Character,Integer> map = new HashMap<>();
		map.put('I', 1);
		map.put('V', 5);
		map.put('X', 10);
		map.put('L', 50);
		map.put('C', 100);
		map.put('D', 500);
		map.put('M', 1000);
		
		roman = roman.replaceAll("IV", "IIII");
		roman = roman.replaceAll("IX", "VIIII");
		roman = roman.replaceAll("XL", "XXXX");
		roman = roman.replaceAll("XC", "LXXXX");
		roman = roman.replaceAll("CD", "CCCC");
		roman = roman.replaceAll("CM", "DCCCC");
		
		int number = 0;
		for(int i=0;i<roman.length();i++)
		{
			number = number+map.get(roman.charAt(i));
		}
		
		System.out.println(number);

	}

}
