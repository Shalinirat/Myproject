package Coding;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Demo {

	public static void main(String[] args) {

       List<Integer> l = Arrays.asList(2,4,3,8,9,11,25,28,2,9);
       //separate even and odd number
       System.out.println(l.stream().collect(Collectors.partitioningBy(t->t%2!=0)));
       
       //remove duplicate
       List<Integer> distinct = l.stream().distinct().collect(Collectors.toList());
       System.out.println(distinct);
       
       //Frequency of each char in string
       String s = "MummyyyY";
       s = s.toLowerCase();      
       Map<String, Long> m = Stream.of(s.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
       System.out.println(m);
       
       //Frequency of number in array
       List<Integer> list = Arrays.asList(2,4,5,2,2,7,5,7,8,8,4,4,4,2);
       System.out.println(list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));
       
       //sort the list in reverse order
       List<Integer> desSort = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
       System.out.println(desSort);
       
       //Join list of String with prefix, suffix and delimiter
       List<String> stringList = Arrays.asList("shalini", "shikha", "rammurti", "Abhishek");
       System.out.println(stringList.stream().collect(Collectors.joining(",", "Hi", "Bye")));
       
       //print multiple of 5 from the list
       List<Integer> list1 = Arrays.asList(2,5,3,8,25,9,100,12,175);
       List<Integer> muliple = list1.stream().filter(t->t%5==0).collect(Collectors.toList());
       System.out.println(muliple);
       
       //find min and max from the list
       //find 3 min and max from the list
       System.out.println(list1.stream().max(Comparator.naturalOrder()).get());
       System.out.println(list1.stream().min(Comparator.naturalOrder()).get());
       
       list1.stream().sorted().limit(3).forEach(System.out::println);
       list1.stream().sorted(Comparator.reverseOrder()).limit(3).forEach(System.out::println);
       
       //merge tow unsorted arrays in sorted array and also remove duplicate
       int[] a = {5,6,1,3,0};
       int[] b = {8,6,9,2,10};
       
       int[] op = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().toArray();
       System.out.println(Arrays.toString(op));
       
       int[] op1 = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().distinct().toArray();
       System.out.println(Arrays.toString(op1));
       
       //find string anagram
       String s1 = "eat";
       String s2 = "ate";
       
       s1 = Stream.of(s1.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
       s2 = Stream.of(s2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
       
       if(s1.equalsIgnoreCase(s2))
    	   System.out.println("Anagram");
       else
    	   System.out.println("No Anagram");
       
       //palindrome String or not
       String s3 = "amma";
       String reverse = Stream.of(s3).map(word->new StringBuffer(word).reverse()).collect(Collectors.joining());
       System.out.println(reverse);
       if(s3.equalsIgnoreCase(reverse))
    	   System.out.println("Palindrome");
       else
    	   System.out.println("No Palindrom");
       
       //sum of digits of a number
       long num = 23456;
       System.out.println(Stream.of(String.valueOf(num).split("")).collect(Collectors.summingLong(Long::parseLong)));
       
       //find second last number in Integer array
       List<Integer> num1 = Arrays.asList(2,6,3,1,9,7,8,11);      
       System.out.println(num1.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get());
       
       //sort List of string increasing order as per length
       List<String> listStr = Arrays.asList("shalini","shalu","batru","shikha","murti","anubhav");
       listStr.stream().sorted(Comparator.comparing(String::length)).forEach(t->System.out.println(t));
       
       
       //common elements b/w two lists
       List<Integer> first = Arrays.asList(2,1,5,7,8);
       List<Integer> second = Arrays.asList(3,7,8,0,9);
       
       List<Integer> common = first.stream().filter(t->second.contains(t)).collect(Collectors.toList());
       System.out.println(common);
       
       
       //find sum and average of array elements
       int[] arr = {1,2,3,4,5,6,7,2,3};
       
       System.out.println(Arrays.stream(arr).sum());
       System.out.println(Arrays.stream(arr).average().getAsDouble());
       
       
       //reverse each word of string
       String line = "my name is shalini";     
       String reverseLine = Stream.of(line.split(" ")).map(word->new StringBuffer(word).reverse()).collect(Collectors.joining(" "));
       System.out.println(reverseLine);
       
       //reverse an integer array
       int[] array = {2,4,7,9,1,0};    
       int[] revArray = IntStream.rangeClosed(1, array.length).map(i->array[array.length-i]).toArray();
       System.out.println(Arrays.toString(revArray));
       
       //find string in list starts with number       
       List<String> ls = Arrays.asList("shalini", "shalu", "1sfghj", "5fhguh");
       ls.stream().filter(str->Character.isDigit(str.charAt(0))).forEach(t->System.out.println(t));
       
       //find duplicate from a list
       List<Integer> lt = Arrays.asList(1,4,5,1,6,7,5);      
       Set<Integer> set = new HashSet<Integer>();
       lt.stream().filter(t->!set.add(t)).forEach(t->System.out.println(t));
       
       
	}

}
