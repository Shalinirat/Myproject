package Coding;

public class LinkedListMain {

	public static void main(String[] args) {

        LinkedList list = new LinkedList();
        
        list.insert(5);
        list.insert(4);
        list.insert(8);
        list.insert(12);
        list.insert(10);
        list.insertAtStart(9);       
        list.insertAt(3, 16);
        
        list.show();
        
	}

}
