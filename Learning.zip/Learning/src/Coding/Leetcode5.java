package Coding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Leetcode5 {

	public static void main(String[] args) {

      // find majority elements in array which is more than n/2 time
      
		int[] arr = {2,2,1,1,1,2,2,5,1,2,1,1,1,2,6,1};
		List<Integer> list = Arrays.asList(2,2,1,1,1,2,2,5,1,2,1,1,1,2,6,1);
		
		Map<Integer, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(map);
		
		for(Map.Entry<Integer, Long> m:map.entrySet())
		{
		  if(m.getValue()>=arr.length/2)
			  System.out.println(m.getKey());
		}
	}

}
