package TestFiles;

import org.testng.Assert;

import PayloadFiles.Payload;
import io.restassured.path.json.JsonPath;

public class complexJsonParsing {

	public static void main(String[] args) {

       String response = Payload.coursePrice();
       JsonPath js = new JsonPath(response);
       
       //Print No of courses returned by API
       int courseCount = js.getInt("courses.size()");
       System.out.println(courseCount);
       
       //Print Purchase Amount
       int purchaseAmout = js.getInt("dashboard.purchaseAmount");
       System.out.println(purchaseAmout);
       
       //Print Title of the first course
       System.out.println(js.getString("courses[0].title"));
       
       //Print All course titles and their respective Prices
       for(int i=0;i<courseCount;i++)
       {
    	   System.out.println(js.getString("courses["+i+"].title"));
    	   System.out.println(js.getInt("courses["+i+"].price"));
       }
       
       //Print no of copies sold by RPA Course
       for(int i=0;i<courseCount;i++)
       {
    	   String course = js.getString("courses["+i+"].title");
    	   if(course.equalsIgnoreCase("RPA"))
    	   {
    		   System.out.println(js.getInt("courses["+i+"].copies"));
    		   break;
    	   }
       }
       
       //Verify if Sum of all Course prices matches with Purchase Amount
       int sum = 0;
       for(int i=0;i<courseCount;i++)
       {
    	   int price = js.getInt("courses["+i+"].price");
    	   int copies = js.getInt("courses["+i+"].copies");
    	   sum=sum+(price*copies);
       }
       System.out.println(sum);
       
       Assert.assertTrue(sum==purchaseAmout);
	}

}
