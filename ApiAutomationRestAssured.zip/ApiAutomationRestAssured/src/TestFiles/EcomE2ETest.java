package TestFiles;

import org.testng.Assert;
import org.testng.annotations.Test;

import PojoClassses.CreateOrderRequest;
import PojoClassses.CreateOrderResponse;
import PojoClassses.GetOrderDetailsResponse;
import PojoClassses.LoginRequest;
import PojoClassses.LoginResponse;
import PojoClassses.Order;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class EcomE2ETest {
	
	@Test
	public void EcommerceOrderE2E()
	{
		//Login to Ecom website
		RequestSpecification loginReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").setContentType(ContentType.JSON)
				                            .build();
		
		LoginRequest login = new LoginRequest();
		login.setUserEmail("ShaliniRathore123@test.com");
		login.setUserPassword("Postman@123");
		
		RequestSpecification loginRequest = given().log().all().spec(loginReq).body(login);
		
		LoginResponse loginResponse = loginRequest.when().post("/api/ecom/auth/login")
				                      .then().log().all().extract().response().as(LoginResponse.class);
		
		String token = loginResponse.getToken();
		String userId = loginResponse.getUserId();
		
		//Create product
		RequestSpecification creatProductReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addHeader("Authorization", token)
				                            .build();
		
		RequestSpecification creatProductRequest = given().log().all().spec(creatProductReq)
		.formParam("productName", "Laptop")
		.formParam("productAddedBy", userId)
		.formParam("productCategory", "Technology")
		.formParam("productSubCategory", "Assesories")
		.formParam("productPrice", "115000")
		.formParam("productDescription", "Macbook")
		.formParam("productFor", "Everyone")
		.multiPart("productImage", new File("C://Users//a889406//Downloads//Apple-MacBook-Air-M1.jpg"));
		
		String createProductResponse = creatProductRequest.when().post("/api/ecom/product/add-product")
				                       .then().log().all().extract().response().asString();
		
		JsonPath js = new JsonPath(createProductResponse);
		String productId = js.getString("productId");
		
		//Create Order
		RequestSpecification createOrderReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").setContentType(ContentType.JSON)
		.addHeader("Authorization", token).build();
		
		CreateOrderRequest createOrder = new CreateOrderRequest();
		Order order = new Order();
		order.setCountry("India");
		order.setProductOrderedId(productId);
		
		List<Order> orderList = new ArrayList<Order>();
		orderList.add(order);
		
		createOrder.setOrders(orderList);
		
		RequestSpecification createOrderRequest = given().log().all().spec(createOrderReq).body(createOrder);
		
		CreateOrderResponse createOrderResponse = createOrderRequest.when().post("/api/ecom/order/create-order")
		.then().log().all().extract().response().as(CreateOrderResponse.class);
		
		String[] orders = createOrderResponse.getOrders();
		String[] productOrderIds = createOrderResponse.getProductOrderId();
		
		String orderNo = orders[0];
		String productOrderId = productOrderIds[0];
		
		//Get Order details
		RequestSpecification getOrderReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addHeader("Authorization", token)
                                                   .addQueryParam("id", orderNo).build();
		RequestSpecification getOrderRequest = given().log().all().spec(getOrderReq);
		
		GetOrderDetailsResponse orderDetails = getOrderRequest.when().get("/api/ecom/order/get-orders-details")
		.then().log().all().extract().response().as(GetOrderDetailsResponse.class);
		
		Assert.assertEquals(orderDetails.getData().get_id(), orderNo);
		Assert.assertEquals(orderDetails.getData().getOrderById(), userId);
		Assert.assertEquals(orderDetails.getData().getProductOrderedId(), productOrderId);
		
		//Delete Product
		
		RequestSpecification delProductReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addHeader("Authorization", token)
                                                     .addPathParam("productid", productId).build();
		
		RequestSpecification delProductRequest = given().log().all().spec(delProductReq);
		
		String delProductRes = delProductRequest.when().delete("/api/ecom/product/delete-product/{productid}")
		.then().log().all().extract().response().asString();
		
		JsonPath js1 = new JsonPath(delProductRes);
		String message = js1.getString("message");
		
		Assert.assertEquals("Product Deleted Successfully", message);
		
	}

}
