import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment3 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(5));

		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		driver.manage().window().maximize();
		w.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
		driver.findElement(By.id("username")).sendKeys("rahulshettyacademy");
		driver.findElement(By.name("password")).sendKeys("learning");
		driver.findElement(By.xpath("(//span[@class='checkmark'])[2]")).click();
		w.until(ExpectedConditions.visibilityOfElementLocated(By.id("okayBtn")));
		driver.findElement(By.id("okayBtn")).click();

		w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[type='checkbox']")));
		Select option = new Select(driver.findElement(By.cssSelector("select[data-style='btn-info']")));
		option.selectByVisibleText("Consultant");

		driver.findElement(By.cssSelector("input[type='checkbox']")).click();
		driver.findElement(By.cssSelector(".btn.btn-info.btn-md")).click();

		w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h4.card-title")));
		String[] itemToSelect = { "iphone X", "Samsung Note 8", "Nokia Edge", "Blackberry" };

		addItemsCart(driver, itemToSelect);

		driver.findElement(By.cssSelector(".nav-link.btn.btn-primary")).click();
	}

	public static void addItemsCart(WebDriver driver, String[] itemToSelect) {

		List<WebElement> products = driver.findElements(By.cssSelector("h4.card-title"));

		int count = 0;

		for (int i = 0; i < products.size(); i++) {
			List<String> itemsList = Arrays.asList(itemToSelect);

			String product = products.get(i).getText();

			if (itemsList.contains(product)) {
				driver.findElements(By.cssSelector(".btn.btn-info")).get(i).click();
				count++;

				if (count == itemToSelect.length)
					break;
			}
		}

	}

}
