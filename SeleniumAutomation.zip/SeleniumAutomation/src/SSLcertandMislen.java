
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;


public class SSLcertandMislen {

	public static void main(String[] args) throws IOException {
		
		ChromeOptions options = new ChromeOptions();
		//FirefoxOptions options = new FirefoxOptions();
		//EdgeOptions options = new EdgeOptions();
		options.setAcceptInsecureCerts(true);
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		//delete all cookies
		driver.manage().deleteAllCookies();
		//driver.manage().deleteCookieNamed("session");  //delete specific cookie
		
		/*System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/geckodriver.exe");
		WebDriver driver = new FirefoxDriver(options);
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/msedgedriver.exe");
		WebDriver driver = new EdgeDriver(options);*/
		
		driver.get("https://expired.badssl.com/");
		System.out.println(driver.getTitle());
		
		//to study about chromeoptions methods
		driver.navigate().to("https://chromedriver.chromium.org/capabilities");
		
		//take a screenshot of open page
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\Users\\a889406\\Downloads\\Selenium\\screenshot.png"));

	}

}
