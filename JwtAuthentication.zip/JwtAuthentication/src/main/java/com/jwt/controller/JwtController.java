package com.jwt.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwtController {
	
	@GetMapping("/welcome")
	public String authenticate()
	{
		String s = "Welcome to the jwt introduction"+"You need JWT token to Authenticate";
		return s;
	}
	

}
