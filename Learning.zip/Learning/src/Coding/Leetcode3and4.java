package Coding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Leetcode3and4 {
	
	public static void main(String args[])
	{
	
		int[] arr = {3,8,2,3,0,0,3,1,8,2,8,9,0,3};
		Arrays.sort(arr);
		//remove all duplicates from array
		List<Integer> l = new ArrayList<>();
		l.add(arr[0]);
		for(int j=0;j<arr.length-1;j++)
		{
			if(arr[j]!=arr[j+1])
				l.add(arr[j+1]);
		}
		System.out.println(l);
		
		//remove duplicates from array and keep element twice
		List<Integer> l1 = new ArrayList<>();
		int j=0;
		for(int i=0;i<arr.length;i++)
		{
			if(i<2 || arr[i]!=arr[j-2]) {
				arr[j]=arr[i];
				l1.add(arr[j]);
				j++;
			}
		}
		System.out.println(l1);
	}
}
