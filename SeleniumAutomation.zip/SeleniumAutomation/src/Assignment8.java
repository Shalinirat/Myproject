import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment8 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://qaclickacademy.com/practice.php");
		driver.manage().window().maximize();
		String country = "United Arab Emirates";
				
		driver.findElement(By.id("autocomplete")).sendKeys("uni");
		Thread.sleep(3000);
		
		List<WebElement> option = driver.findElements(By.xpath("//li[@class='ui-menu-item']/div"));
		
		for(int i=0;i<option.size();i++)
		{
			if(option.get(i).getText().equalsIgnoreCase(country))
			{
				System.out.println(option.get(i).getText());
				option.get(i).click();
				break;
			}
		}
     
		System.out.println(driver.findElement(By.id("autocomplete")).getAttribute("value"));
	}

}
