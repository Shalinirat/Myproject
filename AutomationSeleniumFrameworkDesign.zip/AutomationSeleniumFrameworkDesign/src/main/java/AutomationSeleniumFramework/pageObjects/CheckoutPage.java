package AutomationSeleniumFramework.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import AutomationSeleniumFrameword.Abstracts.AbstractComponent;

public class CheckoutPage extends AbstractComponent{

	WebDriver driver;
	
	public CheckoutPage(WebDriver driver) {
		
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(css="[placeholder='Select Country']")
	WebElement countryName;
	
	@FindBy(css=".action__submit")
	WebElement placeOrder;
	
	@FindBy(xpath="(//span[@class='ng-star-inserted'])[2]")
	WebElement selectedCountry;
	
	By result = By.cssSelector(".ta-results");
	
	public ConfirmationPage selectCountryName(String country)
	{
		Actions a = new Actions(driver);
		a.sendKeys(countryName, country).build().perform();
		waitElementToBeVisible(result);
		selectedCountry.click();
		placeOrder.click();
		
		return new ConfirmationPage(driver);
	}

}
