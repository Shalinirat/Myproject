import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class CalanderUI {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		driver.manage().window().maximize();
		
		String month = "7";
		String date = "27";
		String year = "1997";
		
		String[] expectedList = {month,date,year};
		
		driver.findElement(By.cssSelector(".react-date-picker__calendar-button__icon")).click();
		driver.findElement(By.cssSelector(".react-calendar__navigation__label")).click();
	    driver.findElement(By.cssSelector(".react-calendar__navigation__label")).click();
	    Thread.sleep(3000);
	    int count = 1;
	    while(count>0){
	    
	     List<WebElement> years = driver.findElements(By.cssSelector(".react-calendar__decade-view__years__year"));
	     for(int i=0;i<years.size();i++)
	     {
	       String s = years.get(i).getText();
		   if(s.equals(year))
		   {
			driver.findElement(By.xpath("//button[text()='"+year+"']")).click();   
			count = 0;
			break;
	       }
	     }
	   if(count==0)
	   break;
	   else
	   driver.findElement(By.cssSelector(".react-calendar__navigation__prev-button")).click();
	   }
	    
	    driver.findElements(By.cssSelector(".react-calendar__year-view__months__month")).get(Integer.parseInt(month)-1).click();
	    driver.findElement(By.xpath("//abbr[text()='"+date+"']")).click(); 
	
	    List<WebElement> actualDate = driver.findElements(By.cssSelector(".react-date-picker__inputGroup__input"));
	    
	    for(int i=0;i<actualDate.size();i++)
	    {
	    	System.out.println(actualDate.get(i).getAttribute("value"));
	    	Assert.assertEquals(actualDate.get(i).getAttribute("value"), expectedList[i]);
	    }
	    
	    driver.close();
	    
	}
}
