package com.jpa.test;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.jpa.test.dao.UserRepository;
import com.jpa.test.entity.User;

@SpringBootApplication
public class SpringjpaApplication {

	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(SpringjpaApplication.class, args);
		
		UserRepository userRepository = context.getBean(UserRepository.class);
		
		//create single record
//		User user = new User();
//		user.setName("Shalini");
//		user.setCity("Bangalore");
//		user.setStatus("Java Developer");
//		
//		User user1 = userRepository.save(user);
//		System.out.println(user1);
		
		//create multiple records
//		User user2 = new User();
//		user2.setCity("Mumbai");
//		user2.setName("Shalu");
//		user2.setStatus("Tester");
//		
//		User user3 = new User();
//		user3.setCity("Pune");
//		user3.setName("Shikha");
//		user3.setStatus("Python Developer");
//		
//		List<User> list = List.of(user2,user3);
//		Iterable<User> itr = userRepository.saveAll(list);
//		
//		itr.forEach(t->System.out.println(t));
//		System.out.println("created");
		
		
		//upadate records
//		Optional<User> option = userRepository.findById(3);		
//		User editUser = option.get();
//		editUser.setName("Sakshi");
//		editUser.setStatus("UI Developer");		
//		userRepository.save(editUser);
		
		//get records
//		Iterable<User> allUsers = userRepository.findAll();		
//		allUsers.forEach(t->System.out.println(t));
		
		//delete records
//		userRepository.deleteAll();
//		System.out.println("deleted");
		
	}

}
