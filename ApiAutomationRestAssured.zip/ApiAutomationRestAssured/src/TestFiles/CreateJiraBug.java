package TestFiles;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.File;

public class CreateJiraBug {
	
	@Test
	public void jiraBug()
	{
		
		RestAssured.baseURI = "https://shalinirathore65.atlassian.net";
		
		//create bug
		String createBugResponse = given().header("Content-Type", "application/json")
		.header("Authorization","Basic c2hhbGluaXJhdGhvcmU2NUBnbWFpbC5jb206QVRBVFQzeEZmR0YwY2V3c1B0YzhjSGZlcjBGMnNzWXo4WEptV0hRVkdXYmFrZHdCdDJ4ZGduWWNGaGRnb2FsSmpMZVNGbDlvZk5XNXBSTlNzN0JhRXpkZjJ0ZGtyU1hMTU03UTlZakZDbDZseXZITWNYWVN4UFZCS21lTjdTWDhXYXBBTGFnRTEtbk5uVE1qWHJrSzczMzhwRjRKY3lzbVBHMjNMMkhsMEYxcVcyX3V3M0R1aDFnPTc5RTkyQkM0")
		.body("{\r\n"
				+ "    \"fields\": {\r\n"
				+ "        \"project\": {\r\n"
				+ "            \"key\": \"REST\"\r\n"
				+ "        },\r\n"
				+ "        \"summary\": \"Website is not working\",\r\n"
				+ "        \"issuetype\": {\r\n"
				+ "            \"name\": \"Bug\"\r\n"
				+ "        }\r\n"
				+ "    }\r\n"
				+ "}")
		.log().all().when().post("rest/api/3/issue")
		.then().log().all().assertThat().statusCode(201).extract().response().asString();
		
		JsonPath js = new JsonPath(createBugResponse);
		String bugId = js.getString("id");
		
		System.out.println(bugId);
		
		//attach file
		
		given().pathParam("Key", bugId)
		.header("X-Atlassian-Token", "no-check")
		.header("Authorization","Basic c2hhbGluaXJhdGhvcmU2NUBnbWFpbC5jb206QVRBVFQzeEZmR0YwY2V3c1B0YzhjSGZlcjBGMnNzWXo4WEptV0hRVkdXYmFrZHdCdDJ4ZGduWWNGaGRnb2FsSmpMZVNGbDlvZk5XNXBSTlNzN0JhRXpkZjJ0ZGtyU1hMTU03UTlZakZDbDZseXZITWNYWVN4UFZCS21lTjdTWDhXYXBBTGFnRTEtbk5uVE1qWHJrSzczMzhwRjRKY3lzbVBHMjNMMkhsMEYxcVcyX3V3M0R1aDFnPTc5RTkyQkM0")
		.multiPart("file", new File("C:/Users/a889406/Downloads/RestAssured/Screenshot 2024-06-27 004913.png")).log().all()
		.when().post("rest/api/3/issue/{Key}/attachments")
		.then().log().all().assertThat().statusCode(200);
		
		
	}

}
