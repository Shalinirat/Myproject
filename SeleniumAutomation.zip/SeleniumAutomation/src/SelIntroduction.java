import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelIntroduction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Invoking Browser
		//Chrome - ChromDriver Class
		//FireFox - FirefoxDriver Class
		
		//step to invoke chrome driver
		System.setProperty("webdriver.chrome.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/chromedriver.exe");
		//without upper line Selenium manager will call chromedriver
		WebDriver driver = new ChromeDriver();
		
		//firfoxDriver launch
		//geckoDriver
		System.setProperty("webdriver.gecko.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/geckodriver.exe");
		WebDriver driver1 = new FirefoxDriver();
		
		//MSEdge launch
		//msedgedriver
		System.setProperty("webdriver.edge.driver", "C:/Users/a889406/Downloads/Selenium/webdriver/msedgedriver.exe");
		WebDriver driver2 = new EdgeDriver();
		
		//open javatpoint website
		driver.get("https://www.javatpoint.com/java-tutorial");
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		driver.close();

	}

}
