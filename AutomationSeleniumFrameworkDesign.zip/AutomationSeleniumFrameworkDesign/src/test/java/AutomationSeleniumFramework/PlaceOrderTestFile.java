package AutomationSeleniumFramework;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import AutomationSeleniumFramework.pageObjects.CartPage;
import AutomationSeleniumFramework.pageObjects.CheckoutPage;
import AutomationSeleniumFramework.pageObjects.ConfirmationPage;
import AutomationSeleniumFramework.pageObjects.LandingPage;
import AutomationSeleniumFramework.pageObjects.ProductCatalogue;
import io.github.bonigarcia.wdm.WebDriverManager;

public class PlaceOrderTestFile {

	public static void main(String[] args) {
		
		String productname = "IPHONE 13 PRO";
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		LandingPage landingpage = new LandingPage(driver);
		landingpage.goTo();
		ProductCatalogue productcatalgue = landingpage.loginApplication("Shalini123@gmail.com", "Shalini@123");	
		productcatalgue.addProductToCart(productname);
		CartPage cartpage = productcatalgue.goToCart();
		boolean match = cartpage.verifyCartProductName(productname);
		Assert.assertTrue(match);
		CheckoutPage checkoutpage = cartpage.goToCheckout();
		ConfirmationPage confirmation = checkoutpage.selectCountryName("India");
		String confirmMsg = confirmation.getConfirmationMsg();		
		Assert.assertTrue(confirmMsg.equalsIgnoreCase("THANKYOU FOR THE ORDER."));
		driver.close();

	}

}
